var videos = [
    {
      idx: 1,
      profile_src: 'profile.jpeg',
      thumbnail_src: 'hello.webp',
      title: 'Adele -Hello (Official Video)',
      author: 'adele',
      stat: '조회수 9542만회 2일전'
    },
    {
      idx: 2,
      profile_src: 'profile.jpeg',
      thumbnail_src: 'hello.webp',
      title: 'Adele -Hello (Official Video)',
      author: 'adele',
      stat: '조회수 9542만회 2일전'
    },
    {
      idx: 3,
      profile_src: 'profile.jpeg',
      thumbnail_src: 'hello.webp',
      title: 'Adele -Hello (Official Video)',
      author: 'adele',
      stat: '조회수 9542만회 2일전'
    },
    {
      idx: 4,
      profile_src: 'profile.jpeg',
      thumbnail_src: 'easy-on-me.webp',
      title: 'Adele - Easy On Me (Official Video)',
      author: 'adele',
      stat: '조회수 7542만회 3일전'
    },
    {
      idx: 5,
      profile_src: 'profile.jpeg',
      thumbnail_src: 'hello.webp',
      title: 'Adele -Hello (Official Video)',
      author: 'adele',
      stat: '조회수 9542만회 2일전'
    },
    {
      idx: 6,
      profile_src: 'profile.jpeg',
      thumbnail_src: 'hello.webp',
      title: 'Adele - Easy On Me (Official Video)',
      author: 'adele',
      stat: '조회수 9542만회 2일전'
    },
    {
      idx: 7,
      profile_src: 'profile.jpeg',
      thumbnail_src: 'easy-on-me.webp',
      title: 'Adele - Easy On Me (Official Video)',
      author: 'adele',
      stat: '조회수 7542만회 3일전'
    },
    {
      idx: 8,
      profile_src: 'profile.jpeg',
      thumbnail_src: 'hello.webp',
      title: 'Adele -Hello (Official Video)',
      author: 'adele',
      stat: '조회수 9542만회 2일전'
    },
  ]